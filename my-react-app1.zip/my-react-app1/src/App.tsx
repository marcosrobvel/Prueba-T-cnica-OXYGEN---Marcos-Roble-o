import './App.css'


function App() {
  
    var introducNumb = 0 /*/document.getElementById('introducirNumb')*/;
    var resultado1 = (introducNumb) * (0.621371);
  
    


  return (
    <>


    <div className='encabezado'>

      <p>⮀ unit converter</p>

    </div>

      <div className="divPurple">
        <p className="tituloConvert">convert</p>
        <div>
                    
            <select className="selectUd" id="seleccionarUnidad">
              <option value="km">km ⭢ miles</option>
              <option value="miles">miles ⭢ km</option>
              <option value="feet">feet ⭢ metres</option>
              <option value="metres">metres ⭢ feet</option>
              <option value="cm">cm ⭢ inches</option>
              <option value="inches">inches ⭢ cm</option>
              <option value="yard">yard ⭢ milimitres</option>
              <option value="milimitres">milimitres ⭢ yard</option>
            </select>
            
                <button className="botonFlechas">
                  ⮀
                </button>


            <input className="cajaTexto2" type="number" id="introducirNumb" name="intrNumber"/> km          
                
                <div>

                  <button className="btnCorazon" title='Save'>♡</button>
                  <input type="number" className="cajaResultado" disabled/>                
                                    
                </div>   
                          
        </div>
        
      </div>


    




    <div className='historial'>

      <p className='tituloHistorial'>saved</p>

      <div className='solucionesEjemplo'>

        <p className=''>100 miles ⟷ 160 km &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6 feet ⟷ 1.83 metres&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X</p>
        <p className=''>15 cm ⟷ 5.9 inches &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 yard ⟷ 914.4 milimitres&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X</p>
        <p className=''>100 miles ⟷ 160 km &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6 feet ⟷ 1.83 metres&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X</p>
        <p className=''>15 cm ⟷ 5.9 inches &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 1 yard ⟷ 914.4 milimitres&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; X</p>

      </div>



    </div>


      
    </>
  )
}

export default App


/*try {
            if (option.value == "km"){
              resultado = introducNumb * 0,621371
              
            }
          } catch (error) {
            
          }*/